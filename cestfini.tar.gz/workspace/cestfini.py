# coding: utf-8

# Étape 1:
import csv
import datetime
import json
import requests

# Étape 2:
url = "https://www.cinemamontreal.com/api/v2/locations/latest/7d.json"
fichier = "films.csv"


# Étape 3:
entetes = {
    "User-Agent":"Charlotte Dumoulin - Requête envoyée dans le cadre d'un cours de journalisme informatique 5240",
    "From":"charlottedumoulin95@outlook.fr"
}

# Étape 4:
req = requests.get(url, headers=entetes)
print(req)


# Étape 5:
for k,v in films.items():
	print(k,v)

# Étape 6:	
for cle in films.keys():
	print(cle)

# Étape 7:	
for valeurs in films.values():
	print(valeurs)

# Étape 8:	
print(valeurs["Nouveautés"])

# Étape 9:
for numFilm,infoFilm in films.items():
	if numFilm != "metadata":
		nom = infoFilm["Nouveautés"]
		location = infoFilm["location"]["fr"]
		lieu = location[:location.find(",")+4]
		print(lieu)
		print(infoFilm["origin_time"])
		print(int(infoFilm["local_time_utc_offset"]/3600))

# Étape 10:
fichier = "nouveatécinemamontreal.csv"

# Étape 11:
for numFilm,infoFilm in films.items():
	if numFilm != "metadata":

# Étape 12:
	    films = []

# Étape 13: 
numero = infoFilm["solution_id"]
films.append(numero)

# Étape 14:
location = infoFilm["location"]["fr"]
		lieu = location[:location.find(",")]
		cinema = location[location.find(",")+2:location.find(",")+4]
		films.append(lieu)
		films.append(cinema)

# Étape 15:
		nom = infoFilm["Nouveautés"]
		films.append(nom)


# Étape 16:
		dateUTC = infoFilm["origin_time"]
		films.append(dateUTC)

# Étape 17:
dateUTC = datetime.datetime.strptime(dateUTC, "%Y-%m-%dT%H:%M:%S%z")
		print(dateUTC)

# Étape 18:
f2 = open(fichier,"a")
		Filmcinemamontreal = csv.writer(f2)
		Filmcinemamontreal.writerow(films)

		
